const searchInput = document.getElementById("searchInput");
const cards = [...document.querySelectorAll(".app-card")];
const toast = document.getElementById("toast");
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function filterApps(term) {
  const query = term.trim().toLowerCase();
  let visible = 0;
  cards.forEach(card => {
    const haystack = (card.dataset.name + " " + card.dataset.category).toLowerCase();
    const match = !query || haystack.includes(query);
    card.hidden = !match;
    if (match) visible++;
  });
  if (query && visible === 0) showToast("No sample apps match that search yet.");
}
searchInput.addEventListener("input", event => filterApps(event.target.value));
document.querySelectorAll("[data-search]").forEach(button => {
  button.addEventListener("click", () => {
    const term = button.dataset.search;
    searchInput.value = term;
    filterApps(term);
    document.getElementById("featured").scrollIntoView({behavior:"smooth"});
  });
});
document.querySelectorAll("[data-app]").forEach(button => {
  button.addEventListener("click", () => showToast(button.dataset.app + " is a fictional preview listing. App details are coming soon."));
});
document.getElementById("themeGlow").addEventListener("click", () => {
  document.body.classList.toggle("glow-mode");
  showToast("Nova glow " + (document.body.classList.contains("glow-mode") ? "enabled" : "disabled") + ".");
});
document.getElementById("menuBtn").addEventListener("click", () => {
  showToast("Use the page sections below to explore Nova Store.");
});
document.addEventListener("keydown", event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    searchInput.focus();
  }
});

// Ideas Hub preview: submissions and support votes exist only until this page is refreshed.
const ideaForm = document.getElementById("ideaForm");
const ideaList = document.getElementById("ideaList");
const ideaCount = document.getElementById("ideaCount");
const ideaFeedback = document.getElementById("ideaFeedback");
function refreshIdeaCount() {
  const count = ideaList.querySelectorAll(".idea-card").length;
  ideaCount.textContent = count + (count === 1 ? " idea" : " ideas");
}
function attachVote(button) {
  button.addEventListener("click", () => {
    if (button.disabled) return;
    const number = button.querySelector("b");
    number.textContent = String(Number(number.textContent) + 1);
    button.disabled = true;
    button.firstChild.textContent = "♥ ";
    button.setAttribute("aria-label", "You supported this idea");
  });
}
document.querySelectorAll("[data-vote]").forEach(attachVote);
if (ideaForm) {
  ideaForm.addEventListener("submit", event => {
    event.preventDefault();
    const title = document.getElementById("ideaTitle").value.trim();
    const category = document.getElementById("ideaCategory").value;
    const description = document.getElementById("ideaDescription").value.trim();
    if (!title || !category || !description) return;
    const card = document.createElement("article");
    card.className = "idea-card";
    const top = document.createElement("div"); top.className = "idea-card-top";
    const cat = document.createElement("span"); cat.className = "idea-category"; cat.textContent = category.toUpperCase();
    const demo = document.createElement("span"); demo.className = "idea-demo"; demo.textContent = "YOUR PREVIEW";
    top.append(cat, demo);
    const heading = document.createElement("h4"); heading.textContent = title;
    const body = document.createElement("p"); body.textContent = description;
    const bottom = document.createElement("div"); bottom.className = "idea-card-bottom";
    const label = document.createElement("span"); label.textContent = "✦ Community idea";
    const vote = document.createElement("button"); vote.type = "button"; vote.className = "vote-btn";
    vote.innerHTML = "♡ <b>0</b> support"; attachVote(vote);
    bottom.append(label, vote); card.append(top, heading, body, bottom);
    ideaList.prepend(card); ideaForm.reset(); refreshIdeaCount();
    ideaFeedback.textContent = "Added to this preview. It has not been uploaded or published.";
  });
}
refreshIdeaCount();
